give @s husk_spawn_egg[item_name="Titan Spawn Egg",rarity=uncommon,custom_data={42data:{datapack:{}}},\
    entity_data={id:"minecraft:area_effect_cloud",Duration:10,DurationOnUse:0,custom_particle:{type:"minecraft:block",block_state:{Name:"minecraft:air"}},Radius:.5f,RadiusOnUse:0,RadiusPerTick:0,WaitTime:0,\
        Tags:["42.tag.summon","42.tag.xltt.titan.spawn_marker"]}\
    ]