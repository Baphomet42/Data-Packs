give @s axolotl_spawn_egg[item_name="Weighted Companion Cube",rarity=uncommon,custom_data={42data:{datapack:{}}},\
    lore=[\
        {text:"Euthanize with:",color:"gray",italic:false},\
        {text:"  Fizzle Tool",color:"gray"},\
        ""],\
    entity_data={id:"minecraft:area_effect_cloud",Duration:10,DurationOnUse:0,custom_particle:{type:"minecraft:block",block_state:"minecraft:air"},Radius:.5f,RadiusOnUse:0,RadiusPerTick:0,WaitTime:0,\
        Tags:["42.tag.summon","42.tag.portal.tool.marker","42.tag.portal.tags.has_tick","42.tag.portal.tool.spawn.cube","42.tag.portal.tool.spawn.cube.companion"]}\
    ]