function 42:portal/tag_id
execute as @e[tag=42.portal_id,tag=42.portal_cube_dis] at @s run rotate @s ~ -70
tag @e remove 42.portal_id