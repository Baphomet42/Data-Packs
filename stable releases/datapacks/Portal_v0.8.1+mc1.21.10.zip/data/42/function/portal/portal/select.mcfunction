tellraw @p[tag=42.tag.portal.selected] [{text:"",color:"gray"},\
    {text:"   Portal...",color:"dark_gray"},\
    {text:"\n      "},"[",{text:"Convert to Spawner",color:"#DDDDDD",click_event:{action:"run_command",command:"/trigger 42menu set 4203577"}},"]",\
    {text:" "},{text:"[?]",color:"dark_purple",hover_event:{action:"show_text",value:[{text:"Replace the portal with a portal spawner of the same type. Portal spawners can be powered just like doors. Note: each time a portal spawner is powered, it will create a new portal that will link to the closest player's portals."}]}},\
    {text:"\n      "},"[",{text:"Cycle Skin",color:"#DDDDDD",click_event:{action:"run_command",command:"/trigger 42menu set 4203576"}},"]",\
    {text:" "},{text:"[?]",color:"dark_purple",hover_event:{action:"show_text",value:[{text:"Portal colors work separately from the linking, meaning any pair of colors can be linked or reused. The color of a portal is determined by the gun that shoots it, so cyling the skin here is temporary."}]}},\
    {text:"\n   Misc...",color:"dark_gray"},\
    {text:"\n      "},"[",{text:"Fizzle",color:"#DDDDDD",click_event:{action:"run_command",command:"/trigger 42menu set 4203575"}},"]"\
    ]