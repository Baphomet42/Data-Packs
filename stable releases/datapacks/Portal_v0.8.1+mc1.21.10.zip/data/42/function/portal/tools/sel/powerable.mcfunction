tellraw @p[tag=42.tag.portal.selected] [{text:"",color:"gray"},\
    {text:"   Powerable... ",color:"dark_gray"},{text:"[?]",color:"dark_purple",hover_event:{action:"show_text",value:\
        [\
            "Powerables can be manually overridden, but may cause issues. Depending on the power source, the powerable might either instantly correct itself or be stuck without correcting itself ever.",\
            "\n\nPower Sources:",\
            "\n  Button",\
            "\n  Pedestal Button",\
            "\n  High Energy Pellet Catcher",\
            "\n  Discouragement Beam Receptacle",\
            "\n\nPowerables:",\
            "\n  Door",\
            "\n  Vital Apparatus Vent",\
            "\n  Thermal Discouragement Beam",\
            "\n  Spawner",\
            "\n  Power Wire"\
        ]}}]