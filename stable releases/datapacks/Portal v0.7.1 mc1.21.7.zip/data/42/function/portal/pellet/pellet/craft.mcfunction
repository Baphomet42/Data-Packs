give @s villager_spawn_egg[item_name="High Energy Pellet",rarity=uncommon,custom_data={42data:{datapack_item:{}}},\
    entity_data={id:"minecraft:area_effect_cloud",Duration:10,DurationOnUse:0,custom_particle:{type:"minecraft:block",block_state:{Name:"minecraft:air"}},Radius:.5f,RadiusOnUse:0,RadiusPerTick:0,WaitTime:0,\
        Tags:["42.tag.summon","42.tag.portal.tool.marker","42.tag.portal.tool.spawn.pellet"]}\
    ]
give @s witch_spawn_egg[item_name="High Energy Super Pellet",rarity=uncommon,custom_data={42data:{datapack_item:{}}},\
    entity_data={id:"minecraft:area_effect_cloud",Duration:10,DurationOnUse:0,custom_particle:{type:"minecraft:block",block_state:{Name:"minecraft:air"}},Radius:.5f,RadiusOnUse:0,RadiusPerTick:0,WaitTime:0,\
        Tags:["42.tag.summon","42.tag.portal.tool.marker","42.tag.portal.tool.spawn.pellet","42.tag.portal.tool.spawn.pellet.super"]}\
    ]