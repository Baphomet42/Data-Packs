give @s guardian_spawn_egg[item_name="Link Equipment",rarity=uncommon,custom_data={42data:{datapack_item:{}}},\
    lore=[\
        {text:"Place once to link all unlinked equipment",color:"white",italic:false},\
        {text:"(unlimited range as long as it's loaded)",color:"white",italic:false},\
        {text:"Power Sources:",color:"gray",italic:false},\
        {text:"  Button",color:"gray"},\
        {text:"  Pedestal Button",color:"gray"},\
        {text:"  Pellet Catcher",color:"gray"},\
        {text:"Powerables:",color:"gray",italic:false},\
        {text:"  Door",color:"gray"},\
        {text:"  Vital Apparatus Vent",color:"gray"},\
        {text:"  Spawner",color:"gray"},\
        {text:"  Power Wire",color:"gray"},\
        ""],\
    entity_data={id:"minecraft:area_effect_cloud",Duration:10,DurationOnUse:0,Particle:{type:block,block_state:{Name:air}},Radius:.5f,RadiusOnUse:0,RadiusPerTick:0,WaitTime:0,\
        Tags:["42.tag.summon","42.tag.portal.tool.marker","42.tag.portal.tool.link"]}\
    ]