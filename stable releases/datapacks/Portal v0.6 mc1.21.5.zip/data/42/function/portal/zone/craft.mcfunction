give @s breeze_spawn_egg[item_name="Zone",rarity=uncommon,custom_data={42data:{datapack_item:{}}},\
    lore=[\
        {text:"Select Tool Features:",color:"gray",italic:false},\
        {text:"  Configure Zone",color:"gray"},\
        ""],\
    entity_data={id:"minecraft:area_effect_cloud",Duration:10,DurationOnUse:0,Particle:{type:block,block_state:{Name:air}},Radius:.5f,RadiusOnUse:0,RadiusPerTick:0,WaitTime:0,\
        Tags:["42.tag.summon","42.tag.portal.tool.marker","42.tag.portal.tool.spawn.zone"]}\
    ]