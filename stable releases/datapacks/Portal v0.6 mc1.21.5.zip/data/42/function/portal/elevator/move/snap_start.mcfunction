execute at @e[tag=42.tag.portal.id,tag=42.tag.portal.elevator.start] run tp @s ~ ~.5 ~
tag @s add 42.tag.portal.elevator.at_start
tag @s remove 42.tag.portal.elevator.at_end
function 42:portal/elevator/walls/reset
function 42:portal/elevator/move/snap_rider