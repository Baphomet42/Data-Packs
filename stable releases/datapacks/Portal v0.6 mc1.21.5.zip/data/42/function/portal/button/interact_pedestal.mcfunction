execute if entity @s[tag=42.tag.portal.pedestal] run scoreboard players operation @s 42.obj.portal.time = @s 42.obj.portal.var.x
playsound minecraft:block.lever.click block @a ~ ~ ~ 1 .6
data merge entity @e[tag=42.tag.portal.id,tag=42.tag.portal.pedestal.dis,limit=1] {transformation:{translation:[-.15f,.95f,-.15f]},interpolation_duration:5,start_interpolation:-1}
data merge entity @e[tag=42.tag.portal.id,tag=42.tag.portal.pedestal.hit,limit=1] {response:false}
data remove entity @e[tag=42.tag.portal.id,tag=42.tag.portal.pedestal.hit,limit=1] interaction
function 42:portal/power