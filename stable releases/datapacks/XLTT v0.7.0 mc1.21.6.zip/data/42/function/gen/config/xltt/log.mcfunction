data modify storage 42:config packs.history.xltt set value {version:"v0.7.0 mc1.21.6"}
data modify storage 42:config packs.active.xltt set value {id:1,name:"XLTT",version:"v0.7.0 mc1.21.6"}