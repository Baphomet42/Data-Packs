data modify storage 42:config packs.history.portal set value {version:"v0.10.0+mc26.1"}
data modify storage 42:config packs.active.portal set value {id:3,name:"Portal",version:"v0.10.0+mc26.1"}